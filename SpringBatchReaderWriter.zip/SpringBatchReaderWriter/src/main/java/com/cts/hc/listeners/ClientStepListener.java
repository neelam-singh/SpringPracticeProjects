package com.cts.hc.listeners;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

public class ClientStepListener implements StepExecutionListener{

	public ExitStatus afterStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		return ExitStatus.COMPLETED;
	}

	public void beforeStep(StepExecution arg0) {
		System.out.println("before step execution******");
		
	}

}
