package com.cts.hc.processes;

import com.cts.hc.models.Claim;

public class Claimprocessor implements org.springframework.batch.item.ItemProcessor<Claim, Claim> {

	public Claim process(Claim claim) throws Exception {
		System.out.println("claim is:"+claim);
		return claim;
	}

	

}
