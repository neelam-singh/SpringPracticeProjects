package com.cts.hc.listeners;

import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.scope.context.ChunkContext;

public class ClientChunkListener implements ChunkListener {

	public void afterChunk(ChunkContext arg0) {
		System.out.println("After ChunkListener******");

	}

	public void afterChunkError(ChunkContext arg0) {
		System.out.println("Error ChunkListener******");

	}

	public void beforeChunk(ChunkContext arg0) {
		System.out.println("Before ChunkListener******");

	}

}
