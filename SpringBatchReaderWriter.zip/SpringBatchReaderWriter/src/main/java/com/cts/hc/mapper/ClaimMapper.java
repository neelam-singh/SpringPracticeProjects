package com.cts.hc.mapper;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.cts.hc.models.Claim;

public class ClaimMapper implements FieldSetMapper<Claim>{

	public Claim mapFieldSet(FieldSet fieldSet) throws BindException {
		Claim claim = new Claim();
		//if read from DB start index from 1
		claim.setClaimId(fieldSet.readInt(0));
		claim.setDoc(fieldSet.readString(1));
		claim.setAmount(fieldSet.readInt(2));
		claim.setPolicyHolderName(fieldSet.readString(3));
		return claim;
	}

}
