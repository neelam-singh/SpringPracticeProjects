package com.cts.hc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.cts.hc.models.Claim;

public class ClaimRowMapper implements RowMapper<Claim> {

	public Claim mapRow(ResultSet rs, int rowNum) throws SQLException {
		Claim claim = new Claim();
		// if read from DB start index from 1

		claim.setClaimId(rs.getInt(1));
		claim.setDoc(rs.getString(2));
		claim.setAmount(rs.getInt(3));
		claim.setPolicyHolderName(rs.getString(4));

		return claim;
	}

}
