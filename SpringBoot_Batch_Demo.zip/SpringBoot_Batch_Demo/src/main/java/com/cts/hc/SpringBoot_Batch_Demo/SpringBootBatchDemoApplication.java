package com.cts.hc.SpringBoot_Batch_Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBatchDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBatchDemoApplication.class, args);
	}
}
