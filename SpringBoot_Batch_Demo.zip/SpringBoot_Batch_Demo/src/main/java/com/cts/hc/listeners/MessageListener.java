package com.cts.hc.listeners;


import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

public class MessageListener implements JobExecutionListener {

	@Override
	public void afterJob(JobExecution arg0) {
		System.out.println("after *******");

	}

	@Override
	public void beforeJob(JobExecution arg0) {
		System.out.println("before *******");

	}

}
