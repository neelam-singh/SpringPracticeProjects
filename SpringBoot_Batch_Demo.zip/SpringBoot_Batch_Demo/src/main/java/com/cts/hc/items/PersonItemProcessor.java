package com.cts.hc.items;

import org.springframework.batch.item.ItemProcessor;

import com.cts.hc.model.Person;

public class PersonItemProcessor implements ItemProcessor<Person, Person> {

	@Override
	public Person process(Person personitem) throws Exception {
		return personitem;
	}

}
