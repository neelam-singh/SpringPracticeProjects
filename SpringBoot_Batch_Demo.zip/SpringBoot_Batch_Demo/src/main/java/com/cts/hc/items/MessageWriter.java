package com.cts.hc.items;

import java.util.ArrayList;
import java.util.List;
import org.springframework.batch.item.ItemWriter;

public class MessageWriter implements ItemWriter<String> {
	
	public static List<Object> response = new ArrayList<Object>();;

	@Override
	public void write(List<? extends String> msg) throws Exception {
		response.add(msg);
		for (String message : msg) {
			if (message != null) {
				System.out.println("writer writes message to console:" + message);
			}
		}
	}

}
