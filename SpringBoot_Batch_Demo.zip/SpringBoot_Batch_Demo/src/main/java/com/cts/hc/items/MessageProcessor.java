package com.cts.hc.items;

import org.springframework.batch.item.ItemProcessor;

public class MessageProcessor implements ItemProcessor<String, String> {

	@Override
	public String process(String msg) throws Exception {
		return msg.toUpperCase();
	}

}
