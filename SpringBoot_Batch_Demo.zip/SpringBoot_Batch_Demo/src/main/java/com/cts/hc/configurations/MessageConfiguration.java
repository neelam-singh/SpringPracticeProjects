package com.cts.hc.configurations;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.cts.hc.items.MessageProcessor;
import com.cts.hc.items.MessageReader;
import com.cts.hc.items.MessageWriter;
import com.cts.hc.listeners.MessageListener;

//@Configuration
public class MessageConfiguration {

	@Autowired
	private JobBuilderFactory jobBuilderfactory;
	@Autowired
	private StepBuilderFactory stepbuilderfactory;

	@Bean
	public Job processJob()
	{
		return jobBuilderfactory.get("TestJob")
				.incrementer(new RunIdIncrementer()).listener(listener()).flow(stepBuilder()).end().build();
	}

	@Bean
	public Step stepBuilder() {
		return stepbuilderfactory.get("step1").<String, String>chunk(1)
				.reader(new MessageReader())
				.processor(new MessageProcessor())
				.writer(new MessageWriter()).build();
	}
	
	@Bean
	public JobExecutionListener listener()
	{
		return new MessageListener();
	}
	
	@Bean
	public ResourcelessTransactionManager transactionManager()
	{
		return new ResourcelessTransactionManager();
	}

}
