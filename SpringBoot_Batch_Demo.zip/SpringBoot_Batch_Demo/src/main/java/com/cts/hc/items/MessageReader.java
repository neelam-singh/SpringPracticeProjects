package com.cts.hc.items;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

public class MessageReader implements ItemReader<String> {

	String message[] = { "Spring Batch moving from XML to Annotations*****" };
	private int counter = 0;

	@Override
	public String read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		if (counter < message.length) {
			return message[counter++];
		} else {
			return null;
		}

	}

}
