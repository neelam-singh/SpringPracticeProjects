package standalone;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.messaging.Message;
import org.springframework.messaging.PollableChannel;
@Configuration
public class BeanConfiguration {

	@Bean
	public Message getMessage()
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("httpgateway.xml");
		PollableChannel channel = (PollableChannel) ctx.getBean("quakeinfo.channel");
		//System.out.println(channel.receive());
	     Message message = channel.receive();
	     Object object = message.getPayload();
	     
	     String[] array = object.toString().split(",");
	     System.out.println(array[0]);
		
		return null;
	}
}
