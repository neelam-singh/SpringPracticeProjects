package standalone;

import org.springframework.integration.core.MessageSource;
import org.springframework.messaging.Message;


public class MessageHandler implements MessageSource {

	@Override
	public Message receive() {
		System.out.println("reading messages****");
		Message<?> response = null;
		return response;
	}

}
