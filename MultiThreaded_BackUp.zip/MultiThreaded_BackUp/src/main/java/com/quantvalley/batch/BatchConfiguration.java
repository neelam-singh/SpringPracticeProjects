package com.quantvalley.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import com.quantvalley.batch.listener.FailureEventprocessor;
import com.quantvalley.batch.listener.JobCompletionNotificationListener;
import com.quantvalley.batch.model.FxMarketEvent;
import com.quantvalley.batch.model.FxMarketVolumeStore;
import com.quantvalley.batch.model.Trade;
import com.quantvalley.batch.processor.FxMarketEventProcessor;
import com.quantvalley.batch.reader.FxMarketEventReader;
import com.quantvalley.batch.writer.StockVolumeAggregator;


@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Bean
	public FxMarketVolumeStore fxMarketPricesStore() {
		return new FxMarketVolumeStore();
	}

	// FxMarketEventReader (Reader)
	@Bean
	public FxMarketEventReader stockReader() {
		return new FxMarketEventReader();
	}

	// FxMarketEventProcessor (Processor)
	@Bean
	public FxMarketEventProcessor stockProcessor() {
		return new FxMarketEventProcessor();
	}

	// StockVolumeAggregator (Writer)
	@Bean
	public StockVolumeAggregator stockVolumeAggregator() {
		return new StockVolumeAggregator();
	}

	// JobCompletionNotificationListener (File loader)
	@Bean
	public JobExecutionListener listener() {
		return new JobCompletionNotificationListener();
	}

	@Bean
	public FailureEventprocessor failureTasklet() {
		return new FailureEventprocessor();
	}

	@Bean
	public FlowDecision decision() {
		return new FlowDecision();
	}

	// Configure job step
	@Bean
	public Job fxMarketPricesETLJob() {

		FlowBuilder<Flow> flowBuilder = new FlowBuilder<Flow>("flow1");

		Flow flow = flowBuilder.start(etlStep()).next(decision()).on(decision().COMPLETED).to(etlStep2())
				.from(decision()).on(decision().FAILURE).to(etlStep3()).end();

		return jobBuilderFactory.get("FxMarket Volume ETL Job").incrementer(new RunIdIncrementer()).listener(listener())
				.flow(etlStep()).end().build();
	}

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor asyncTaskExecutor = new SimpleAsyncTaskExecutor("spring_batch");
		asyncTaskExecutor.setConcurrencyLimit(5);
		return asyncTaskExecutor;
	}

	@Bean
	public Step etlStep() {
		return stepBuilderFactory.get("Extract -> Transform -> Aggregate -> Load").<FxMarketEvent, Trade>chunk(100)
				.reader(stockReader())
				//.processor(stockProcessor())
				//.writer(stockVolumeAggregator())
				.taskExecutor(taskExecutor()).build();
	}

	@Bean
	public Step etlStep2() {
		return stepBuilderFactory.get("Aggregate -> Load").<FxMarketEvent, Trade>chunk(100)
				.processor(stockProcessor())
				.writer(stockVolumeAggregator()).build();

	}

	@Bean
	public Step etlStep3() {
		return stepBuilderFactory.get("Failure").tasklet(failureTasklet()).build();

	}

}
