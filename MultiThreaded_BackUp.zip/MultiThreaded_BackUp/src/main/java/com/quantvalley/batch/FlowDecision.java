package com.quantvalley.batch;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

public class FlowDecision implements JobExecutionDecider {
	
	public static final String COMPLETED = "COMPLETED";
	public static final String FAILURE = "FAILURE";
	

	@Override
	public FlowExecutionStatus decide(JobExecution jobEx, StepExecution stepex) {
		if (stepex.getExitStatus().equals(ExitStatus.COMPLETED))
			return FlowExecutionStatus.COMPLETED;
		else
			return FlowExecutionStatus.FAILED;
	}

}
